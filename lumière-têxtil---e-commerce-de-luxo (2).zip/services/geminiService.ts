
import { GoogleGenAI } from "@google/genai";
import { Product } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // Initializing Gemini AI with process.env.API_KEY as per guidelines
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async smartSearch(query: string, catalog: Product[]): Promise<Product[]> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Analise a consulta do usuário: "${query}". 
        Com base no catálogo de produtos: ${JSON.stringify(catalog.map(p => ({ id: p.id, name: p.name, category: p.category, description: p.description })))}.
        Retorne APENAS uma lista de IDs dos produtos que melhor correspondem à intenção do usuário, mesmo que a busca seja vaga (ex: "algo para o frio" ou "presente para casamento").
        Formato de resposta: JSON array de strings.`,
        config: {
          responseMimeType: "application/json"
        }
      });

      // Extracting text output directly from property .text
      const ids = JSON.parse(response.text || '[]');
      return catalog.filter(p => ids.includes(p.id));
    } catch (error) {
      console.error("Gemini Search Error:", error);
      return [];
    }
  }

  async getPersonalizedRecommendation(product: Product): Promise<string> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Você é um especialista em design de interiores e têxteis da Lumière Têxtil. 
        O cliente está vendo o produto: ${product.name} (${product.category}).
        Crie um parágrafo curto e persuasivo (máximo 40 palavras) explicando por que este produto traz conforto e sofisticação para o lar. Use um tom acolhedor e profissional.`,
      });
      // Extracting text output directly from property .text
      return response.text || "Uma escolha impecável para quem valoriza o bem-estar e a elegância em cada detalhe da casa.";
    } catch (error) {
      return "Uma escolha impecável para quem valoriza o bem-estar e a elegância em cada detalhe da casa.";
    }
  }
}

export const geminiService = new GeminiService();
