
import { Product, Category } from './types';

// The site now starts empty. Users will add items.
export const MOCK_PRODUCTS: Product[] = [];

export const CATEGORIES = Object.values(Category);
