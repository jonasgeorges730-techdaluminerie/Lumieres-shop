
export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  description: string;
  image: string;
  colors: string[];
  sizes?: string[];
  fabric: string;
  rating: number;
  reviews: number;
  isNew?: boolean;
  isOnSale?: boolean;
  inStock?: boolean; // Campo de disponibilidade
  sellerEmail: string;
}

export interface CartItem extends Product {
  quantity: number;
  selectedColor: string;
  selectedSize?: string;
}

export type DeliveryMethod = 'retirada' | 'motoboy' | 'frete';
export type OrderStatus = 'pendente' | 'pago_custodia' | 'enviado' | 'concluido' | 'disputa';

export interface Order {
  id: string;
  buyerEmail: string;
  sellerEmail: string;
  items: CartItem[];
  total: number;
  status: OrderStatus;
  createdAt: number;
}

export interface UserAccount {
  email: string;
  name: string;
  isBanned: boolean;
  pendingFees: number;
  balance: number; // Saldo disponível para saque
}

export enum Category {
  BEDDING = 'Cama',
  BATH = 'Banho',
  TABLE = 'Mesa',
  CURTAINS = 'Cortinas',
  CLOTHING = 'Roupas',
  DECOR = 'Decoração'
}
