
import React, { useState, useEffect, useMemo } from 'react';
import { HashRouter, Routes, Route, Link, useParams, useNavigate, useLocation } from 'react-router-dom';
import { 
  ShoppingBag, Menu, X, Search, Heart, Star, Check, ShieldCheck, PlusCircle, 
  Truck, ArrowLeft, CreditCard, AlertTriangle, Settings, User, 
  LogOut, Wallet, Package, Clock, CheckCircle2, Filter, ChevronRight, Trash2, Loader2,
  ChevronDown, SlidersHorizontal, Github, Copy, ExternalLink, Sparkles, Globe, Layout,
  Zap, Info, HelpCircle, Share2, Link as LinkIcon, Code2, Play, Lock, PackageOpen
} from 'lucide-react';
import { Product, CartItem, Category, UserAccount, Order, OrderStatus } from './types';
import { CATEGORIES } from './constants';
import { geminiService } from './services/geminiService';

const ADMIN_EMAIL = 'Jonasgeorges730@gmail.com';

// --- Auth Hook ---
const useAuth = () => {
  const [user, setUser] = useState<UserAccount | null>(() => {
    const saved = localStorage.getItem('lumiere_user');
    return saved ? JSON.parse(saved) : null;
  });

  const login = (email: string, name: string) => {
    const allUsers = JSON.parse(localStorage.getItem('lumiere_all_users') || '{}');
    let userData = allUsers[email];
    if (!userData) {
      userData = { email, name, isBanned: false, pendingFees: 0, balance: 0 };
      allUsers[email] = userData;
    }
    setUser(userData);
    localStorage.setItem('lumiere_user', JSON.stringify(userData));
    localStorage.setItem('lumiere_all_users', JSON.stringify(allUsers));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('lumiere_user');
  };

  const refreshUser = () => {
    if (!user) return;
    const allUsers = JSON.parse(localStorage.getItem('lumiere_all_users') || '{}');
    const updated = allUsers[user.email];
    if (updated) {
      setUser(updated);
      localStorage.setItem('lumiere_user', JSON.stringify(updated));
    }
  };

  return { user, login, logout, setUser, refreshUser };
};

// --- Components ---

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
};

const BannedOverlay: React.FC<{ user: UserAccount }> = ({ user }) => (
  <div className="fixed inset-0 z-[2000] bg-white flex items-center justify-center p-8 text-center animate-in fade-in duration-500">
    <div className="max-w-md space-y-8">
      <div className="w-24 h-24 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto animate-bounce">
        <AlertTriangle size={48} />
      </div>
      <h2 className="text-4xl font-serif font-bold text-brand-olive">Acesso Bloqueado</h2>
      <p className="text-brand-gray leading-relaxed">
        Identificamos irregularidades ou taxas pendentes vinculadas à sua conta/dispositivo.
      </p>
      <div className="bg-brand-beige p-6 rounded-2xl border-2 border-brand-gold/20">
        <p className="text-[10px] uppercase tracking-widest font-bold text-brand-gold">Valor para Desbloqueio</p>
        <p className="text-3xl font-serif font-bold text-brand-olive">R$ {user.pendingFees.toFixed(2)}</p>
      </div>
      <p className="text-sm italic text-brand-gray">Envie o PIX para o administrador e seu acesso será liberado automaticamente após a confirmação.</p>
      <button onClick={() => window.open('https://wa.me/5500000000000', '_blank')} className="w-full bg-brand-olive text-white py-6 rounded-2xl font-bold uppercase tracking-widest shadow-xl">Contatar Suporte / Pagar</button>
    </div>
  </div>
);

const Navbar: React.FC<{ 
  cartCount: number; user: UserAccount | null;
  onOpenCart: () => void; onOpenSearch: () => void; onOpenAddItem: () => void;
  onOpenAuth: () => void; onLogout: () => void; onOpenAdmin: () => void;
}> = ({ cartCount, user, onOpenCart, onOpenSearch, onOpenAddItem, onOpenAuth, onLogout, onOpenAdmin }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const isAdmin = user?.email === ADMIN_EMAIL;

  return (
    <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-brand-beige">
      <div className="max-w-7xl mx-auto px-4 h-20 md:h-24 flex justify-between items-center">
        <button onClick={() => setIsMenuOpen(true)} className="md:hidden p-2"><Menu size={24} /></button>
        <div className="hidden md:flex items-center space-x-8 text-[10px] font-bold uppercase tracking-widest text-brand-gray">
          <Link to="/" className="hover:text-brand-gold transition">Home</Link>
          <Link to="/shop" className="hover:text-brand-gold transition">Loja</Link>
          <button onClick={onOpenAddItem} className="text-brand-olive flex items-center gap-1 hover:text-brand-gold transition-colors">
            <PlusCircle size={14}/>Vender
          </button>
          {isAdmin && (
            <button onClick={onOpenAdmin} className="text-brand-gold flex items-center gap-1 hover:scale-110 transition-transform">
              <Settings size={14} className="animate-spin-slow" />Painel
            </button>
          )}
        </div>
        <Link to="/" className="flex flex-col items-center">
          <span translate="no" className="notranslate font-serif text-2xl font-bold text-brand-olive uppercase tracking-tighter brand-name">Lumière</span>
          <div className="flex items-center gap-1">
            <Lock size={8} className="text-brand-gold" />
            <span className="text-[7px] uppercase tracking-[0.4em] font-bold text-brand-gold">Conexão Segura</span>
          </div>
        </Link>
        <div className="flex items-center space-x-2">
          <button onClick={onOpenSearch} className="p-3"><Search size={20} /></button>
          <button onClick={onOpenCart} className="p-3 relative">
            <ShoppingBag size={20} />
            {cartCount > 0 && <span className="absolute top-2 right-2 bg-brand-terracotta text-white text-[8px] w-4 h-4 rounded-full flex items-center justify-center">{cartCount}</span>}
          </button>
          {user ? (
            <div className="hidden md:flex items-center space-x-4 pl-4 border-l">
              <div className="flex flex-col items-end">
                <span className="text-[9px] font-bold text-brand-olive uppercase">{user.name.split(' ')[0]}</span>
                <span className="text-[8px] text-brand-gold font-bold">R$ {user.balance.toFixed(2)}</span>
              </div>
              <button onClick={onLogout} className="text-gray-400 hover:text-red-500 transition-colors ml-2"><LogOut size={16} /></button>
            </div>
          ) : (
            <button onClick={onOpenAuth} className="p-3"><User size={20} /></button>
          )}
        </div>
      </div>
      {isMenuOpen && (
        <div className="fixed inset-0 z-[100] bg-white p-8 animate-in slide-in-from-left">
          <div className="flex justify-between items-center mb-12">
            <span className="font-serif text-3xl font-bold">Menu</span>
            <button onClick={() => setIsMenuOpen(false)}><X size={32} /></button>
          </div>
          <div className="flex flex-col space-y-8 text-2xl font-serif">
            <Link to="/" onClick={() => setIsMenuOpen(false)}>Início</Link>
            <Link to="/shop" onClick={() => setIsMenuOpen(false)}>Catálogo</Link>
            <button onClick={() => { setIsMenuOpen(false); onOpenAddItem(); }} className="text-brand-olive font-bold text-left flex items-center gap-2">
              <PlusCircle size={24}/> Vender Item
            </button>
            {isAdmin && (
              <button onClick={() => { setIsMenuOpen(false); onOpenAdmin(); }} className="text-brand-gold font-bold text-left flex items-center gap-2">
                <Settings size={24}/> Painel Master
              </button>
            )}
            {!user ? (
              <button onClick={() => { setIsMenuOpen(false); onOpenAuth(); }} className="text-left flex items-center gap-2">
                <User size={24}/> Entrar
              </button>
            ) : (
              <button onClick={() => { setIsMenuOpen(false); onLogout(); }} className="text-red-500 text-left flex items-center gap-2">
                <LogOut size={24}/> Sair da Conta
              </button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

// --- Pages ---

const Home = ({ catalog, onAddToCart }: { catalog: Product[], onAddToCart: (p: Product) => void }) => (
  <div>
    <div className="h-[80vh] relative flex items-center justify-center overflow-hidden bg-brand-beige">
      <div className="absolute inset-0 bg-black/20 z-10" />
      <img src="https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&q=80" className="absolute inset-0 w-full h-full object-cover scale-105" alt="Luxury textiles" />
      <div className="relative z-20 text-center text-white px-6 max-w-4xl">
        <span className="text-[10px] uppercase tracking-[0.6em] font-bold mb-6 block animate-in fade-in slide-in-from-bottom duration-700">Curadoria Exclusiva</span>
        <h1 className="text-6xl md:text-9xl font-serif font-bold mb-8 leading-none animate-in fade-in slide-in-from-bottom duration-1000">Arte em cada trama</h1>
        <p className="text-lg md:text-xl font-light mb-12 max-w-2xl mx-auto italic opacity-90">Transformando ambientes através do luxo têxtil e da sofisticação atemporal.</p>
        <Link to="/shop" className="bg-white text-brand-olive px-12 py-6 rounded-full uppercase tracking-widest font-bold text-[10px] hover:bg-brand-gold hover:text-white transition-all shadow-2xl hover:scale-105 active:scale-95 inline-block">Explorar Coleção</Link>
      </div>
    </div>

    <div className="max-w-7xl mx-auto px-6 py-32">
      <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
        <div className="max-w-xl">
          <h2 className="text-[10px] uppercase tracking-[0.4em] font-bold text-brand-gold mb-4"><span translate="no" className="notranslate">Lumière</span> Selection</h2>
          <h3 className="text-5xl font-serif font-bold text-brand-olive leading-tight">Peças que contam histórias de conforto</h3>
        </div>
        <Link to="/shop" className="group flex items-center gap-3 text-[10px] uppercase font-bold tracking-widest text-brand-gray hover:text-brand-gold transition-colors">
          Ver catálogo completo <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
        </Link>
      </div>
      
      {catalog.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
          {catalog.slice(0, 4).map(p => (
            <ProductCard key={p.id} product={p} onAddToCart={onAddToCart} />
          ))}
        </div>
      ) : (
        <div className="py-20 text-center bg-brand-beige/30 rounded-[48px] border-2 border-dashed border-brand-beige">
          <PackageOpen className="mx-auto text-brand-gold/30 mb-6" size={64} />
          <p className="font-serif text-2xl text-brand-gray/50 italic">Novidades em breve...</p>
        </div>
      )}
    </div>
  </div>
);

const Shop = ({ catalog, onAddToCart }: { catalog: Product[], onAddToCart: (p: Product) => void }) => {
  const [filter, setFilter] = useState('Todos');
  const filteredProducts = catalog.filter(p => filter === 'Todos' || p.category === filter);

  return (
    <div className="max-w-7xl mx-auto px-6 py-16">
      <h1 className="text-6xl font-serif font-bold text-brand-olive mb-12">Catálogo</h1>
      <div className="flex flex-wrap gap-4 mb-12">
        {['Todos', ...CATEGORIES].map(cat => (
          <button 
            key={cat} 
            onClick={() => setFilter(cat)}
            className={`px-8 py-3 rounded-full text-[10px] uppercase font-bold tracking-widest transition-all border ${filter === cat ? 'bg-brand-gold text-white border-brand-gold' : 'bg-white text-brand-gray border-brand-beige'}`}
          >
            {cat}
          </button>
        ))}
      </div>

      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-12 gap-y-20">
          {filteredProducts.map(p => (
            <ProductCard key={p.id} product={p} onAddToCart={onAddToCart} />
          ))}
        </div>
      ) : (
        <div className="py-40 text-center">
          <PackageOpen className="mx-auto text-brand-gold/20 mb-8" size={80} />
          <h2 className="text-3xl font-serif text-brand-olive mb-4">Nenhum item encontrado</h2>
          <p className="text-brand-gray text-sm uppercase tracking-widest font-bold opacity-60">Em breve novos produtos exclusivos <span translate="no" className="notranslate">Lumière</span>.</p>
        </div>
      )}
    </div>
  );
};

const ProductCard: React.FC<{ product: Product, onAddToCart: (p: Product) => void }> = ({ product, onAddToCart }) => (
  <div className="group flex flex-col h-full bg-white rounded-[32px] overflow-hidden hover:shadow-2xl transition-all duration-700 border border-brand-beige">
    <div className="block relative aspect-[4/5] overflow-hidden bg-brand-beige">
      <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
      <div className="absolute top-6 left-6">
        {product.isNew && <span className="bg-brand-olive text-white text-[8px] uppercase font-bold px-4 py-1.5 rounded-full tracking-widest">Novo</span>}
      </div>
    </div>
    <div className="p-8 flex flex-col flex-grow text-center space-y-4">
      <p className="text-[10px] uppercase tracking-[0.3em] text-brand-gold font-bold">{product.category}</p>
      <h4 className="text-[13px] font-bold uppercase tracking-widest text-brand-gray line-clamp-2 h-10 flex items-center justify-center leading-tight">{product.name}</h4>
      <p className="font-serif text-2xl font-bold text-brand-olive">R$ {product.price.toFixed(2)}</p>
      <button onClick={() => onAddToCart(product)} className="mt-auto w-full py-5 rounded-2xl text-[10px] uppercase font-bold tracking-[0.2em] transition-all bg-brand-gray text-white hover:bg-brand-olive">Adicionar</button>
    </div>
  </div>
);

const AdminPanel = ({ isOpen, onClose, onManage, catalog, onRemoveProduct }: any) => {
  const [e, setE] = useState('');
  const [f, setF] = useState(0);
  const [view, setView] = useState<'users' | 'catalog' | 'deploy'>('catalog');
  const [githubUrl, setGithubUrl] = useState(() => localStorage.getItem('lumiere_github_url') || '');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    localStorage.setItem('lumiere_github_url', githubUrl);
  }, [githubUrl]);

  const embedCode = `<div style="width:100%; height:100vh; overflow:hidden;">
  <iframe src="${githubUrl || 'SEU-LINK-GITHUB-AQUI'}" style="width:100%; height:100%; border:none;" allow="camera; microphone; geolocation;"></iframe>
</div>`;

  const copyEmbed = () => {
    navigator.clipboard.writeText(embedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const testLink = () => {
    if (githubUrl) window.open(githubUrl, '_blank');
  };

  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-brand-olive/80 backdrop-blur-xl" onClick={onClose} />
      <div className="relative bg-white w-full max-w-5xl rounded-[48px] shadow-2xl max-h-[95vh] overflow-hidden flex flex-col animate-in zoom-in-95 duration-300">
        <div className="p-8 md:p-10 border-b border-brand-beige flex justify-between items-center bg-brand-offwhite">
          <div>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-brand-olive brand-name" translate="no"><span translate="no" className="notranslate">Lumière</span> Hub</h2>
            <p className="text-[10px] uppercase font-bold text-brand-gold tracking-widest mt-1">Gestão Técnica & Visual</p>
          </div>
          <button onClick={onClose} className="p-4 hover:bg-brand-beige rounded-full transition-colors"><X size={32}/></button>
        </div>

        <div className="flex border-b border-brand-beige bg-white overflow-x-auto scroll-hide">
           <button onClick={() => setView('catalog')} className={`flex-1 min-w-[150px] py-5 text-[10px] uppercase font-bold tracking-widest transition-all ${view === 'catalog' ? 'border-b-4 border-brand-olive text-brand-olive bg-brand-beige/20' : 'text-gray-400'}`}>Produtos</button>
           <button onClick={() => setView('deploy')} className={`flex-1 min-w-[150px] py-5 text-[10px] uppercase font-bold tracking-widest transition-all flex items-center justify-center gap-2 ${view === 'deploy' ? 'border-b-4 border-brand-olive text-brand-olive bg-brand-beige/20' : 'text-gray-400'}`}>
             <Globe size={14}/> Publicação (HTTPS)
           </button>
           <button onClick={() => setView('users')} className={`flex-1 min-w-[150px] py-5 text-[10px] uppercase font-bold tracking-widest transition-all ${view === 'users' ? 'border-b-4 border-brand-olive text-brand-olive bg-brand-beige/20' : 'text-gray-400'}`}>Clientes</button>
        </div>

        <div className="flex-grow overflow-y-auto p-6 md:p-10 scroll-hide">
          {view === 'catalog' && (
            <div className="space-y-6 animate-in fade-in">
              {catalog.length > 0 ? (
                catalog.map((p: any) => (
                  <div key={p.id} className="flex items-center justify-between p-6 bg-brand-offwhite rounded-3xl border border-brand-beige">
                    <div className="flex items-center gap-6">
                      <img src={p.image} className="w-16 h-16 rounded-2xl object-cover shadow-sm" />
                      <div>
                        <p className="text-sm font-bold uppercase text-brand-gray">{p.name}</p>
                        <p className="text-[10px] text-brand-gold font-bold uppercase tracking-widest">R$ {p.price.toFixed(2)}</p>
                      </div>
                    </div>
                    <button onClick={() => onRemoveProduct(p.id)} className="p-4 text-red-400 hover:bg-red-50 rounded-2xl transition-all" title="Remover permanentemente"><Trash2 size={20} /></button>
                  </div>
                ))
              ) : (
                <div className="text-center py-20">
                  <p className="text-brand-gray/50 uppercase text-[10px] font-bold tracking-[0.2em]">O seu catálogo está vazio no momento.</p>
                </div>
              )}
            </div>
          )}

          {view === 'deploy' && (
            <div className="space-y-12 animate-in fade-in duration-500">
              <div className="bg-green-50 border border-green-200 p-6 rounded-3xl flex items-center gap-4">
                <ShieldCheck className="text-green-600" size={32} />
                <div>
                  <h4 className="text-sm font-bold text-green-800 uppercase">Segurança Automática (SSL/HTTPS)</h4>
                  <p className="text-[10px] text-green-700 leading-relaxed">O cadeado de segurança será ativado sozinho pelo GitHub e Google Sites.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="space-y-8">
                  <h3 className="text-2xl font-serif font-bold text-brand-olive">1. O Motor (GitHub)</h3>
                  <div className="space-y-4">
                    <div className="relative">
                      <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-gold" size={18} />
                      <input 
                        type="text" 
                        placeholder="Cole seu link do GitHub aqui..." 
                        className="w-full bg-brand-offwhite border border-brand-beige p-5 pl-12 rounded-2xl outline-none focus:ring-2 ring-brand-gold/20 text-xs font-mono"
                        value={githubUrl}
                        onChange={(e) => setGithubUrl(e.target.value)}
                      />
                    </div>
                    <button 
                      onClick={testLink}
                      disabled={!githubUrl}
                      className="w-full flex items-center justify-center gap-3 bg-brand-olive text-white py-4 rounded-2xl font-bold uppercase tracking-widest text-[10px] hover:bg-brand-gray transition-all disabled:opacity-30"
                    >
                      <Play size={14}/> Testar Link da Loja
                    </button>
                  </div>
                </div>

                <div className="space-y-8">
                  <h3 className="text-2xl font-serif font-bold text-brand-olive">2. A Vitrine (Google Sites)</h3>
                  <div className="bg-brand-gray p-6 rounded-[32px] relative group border-4 border-brand-beige shadow-inner">
                    <code className="text-[10px] text-brand-beige break-all block py-4 pr-12 font-mono leading-relaxed">
                      {embedCode}
                    </code>
                    <button 
                      onClick={copyEmbed}
                      className="absolute right-6 top-1/2 -translate-y-1/2 p-4 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-all"
                    >
                      {copied ? <Check size={20}/> : <Copy size={20}/>}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {view === 'users' && (
            <div className="space-y-8 animate-in fade-in max-w-lg mx-auto py-10">
              <h3 className="text-2xl font-serif font-bold text-center text-brand-olive">Moderação de Usuários</h3>
              <input placeholder="E-mail do Alvo" className="w-full bg-brand-offwhite border border-brand-beige p-6 rounded-2xl outline-none" onChange={ev => setE(ev.target.value)} />
              <input placeholder="Taxa/Multa Pendente (R$)" type="number" className="w-full bg-brand-offwhite border border-brand-beige p-6 rounded-2xl outline-none" onChange={ev => setF(parseFloat(ev.target.value))} />
              <button onClick={() => onManage(e, f)} className="w-full bg-brand-olive text-white py-6 rounded-2xl font-bold uppercase tracking-widest text-[11px] shadow-xl hover:bg-brand-gray transition-all">Aplicar Restrição</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// --- App Entry ---

export default function App() {
  const { user, login, logout, refreshUser } = useAuth();
  
  const [catalog, setCatalog] = useState<Product[]>(() => {
    const saved = localStorage.getItem('lumiere_catalog');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isAddItemOpen, setIsAddItemOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('lumiere_catalog', JSON.stringify(catalog));
  }, [catalog]);

  const addProduct = (p: Partial<Product>) => {
    const newP = { 
      ...p, 
      id: Date.now().toString(), 
      sellerEmail: user?.email || ADMIN_EMAIL, 
      rating: 5, 
      reviews: 0, 
      inStock: true,
      isNew: true 
    } as Product;
    setCatalog(prev => [newP, ...prev]);
    setIsAddItemOpen(false);
  };

  const removeProduct = (id: string) => {
    setCatalog(prev => prev.filter(p => p.id !== id));
  };

  const manageBan = (email: string, fee: number) => {
    const allUsers = JSON.parse(localStorage.getItem('lumiere_all_users') || '{}');
    if (allUsers[email]) {
      allUsers[email].isBanned = fee > 0;
      allUsers[email].pendingFees = fee;
      localStorage.setItem('lumiere_all_users', JSON.stringify(allUsers));
      if (user?.email === email) refreshUser();
    }
  };

  return (
    <HashRouter>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col font-sans bg-brand-offwhite text-brand-gray">
        {user?.isBanned && <BannedOverlay user={user} />}
        
        <Navbar 
          cartCount={cart.length} user={user}
          onOpenCart={() => setIsCartOpen(true)} onOpenSearch={() => {}} 
          onOpenAddItem={() => setIsAddItemOpen(true)} onOpenAuth={() => setIsAuthOpen(true)}
          onLogout={logout} onOpenAdmin={() => setIsAdminOpen(true)}
        />

        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home catalog={catalog} onAddToCart={(p) => { setCart([...cart, {...p, quantity: 1, selectedColor: 'Padrão'}]); setIsCartOpen(true); }} />} />
            <Route path="/shop" element={<Shop catalog={catalog} onAddToCart={(p) => { setCart([...cart, {...p, quantity: 1, selectedColor: 'Padrão'}]); setIsCartOpen(true); }} />} />
          </Routes>
        </main>
        
        <footer className="bg-brand-gray text-white pt-20 pb-12 px-6">
          <div className="max-w-7xl mx-auto flex flex-col items-center space-y-8">
            <span translate="no" className="notranslate font-serif text-3xl font-bold tracking-tighter uppercase brand-name">Lumière</span>
            <div className="flex flex-wrap justify-center gap-12 text-[10px] uppercase font-bold tracking-[0.2em] opacity-60">
              <Link to="/" className="hover:text-brand-gold">Home</Link>
              <Link to="/shop" className="hover:text-brand-gold">Coleções</Link>
              <button className="hover:text-brand-gold">Privacidade</button>
              <button className="hover:text-brand-gold">Termos</button>
            </div>
            
            <div className="flex items-center gap-6 py-8 border-y border-white/10 w-full justify-center">
              <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-full">
                <Lock size={12} className="text-brand-gold" />
                <span className="text-[9px] uppercase font-bold tracking-widest">SSL Ativo</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-white/5 rounded-full">
                <ShieldCheck size={12} className="text-brand-gold" />
                <span className="text-[9px] uppercase font-bold tracking-widest">SafePay</span>
              </div>
            </div>

            <p className="text-[9px] uppercase tracking-widest opacity-40 text-center">
              © 2025 <span translate="no" className="notranslate">Lumière</span> Têxtil. Protegido por criptografia HTTPS.
            </p>
          </div>
        </footer>

        <AdminPanel 
          isOpen={isAdminOpen} 
          onClose={() => setIsAdminOpen(false)} 
          catalog={catalog} 
          onRemoveProduct={removeProduct} 
          onManage={manageBan} 
        />
        
        <AddItemModal isOpen={isAddItemOpen} onClose={() => setIsAddItemOpen(false)} onAdd={addProduct} />
        <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} onLogin={login} />
        <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} items={cart} />
      </div>
    </HashRouter>
  );
}

// Sub-modais auxiliares
const AuthModal = ({ isOpen, onClose, onLogin }: any) => {
  const [e, setE] = useState('');
  const [n, setN] = useState('');
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-md p-10 rounded-[32px] shadow-2xl space-y-6 animate-in zoom-in-95">
        <h2 className="text-3xl font-serif font-bold">Acesso <span translate="no" className="notranslate">Lumière</span></h2>
        <input placeholder="Nome" className="w-full bg-brand-beige p-5 rounded-xl outline-none" onChange={ev => setN(ev.target.value)} />
        <input placeholder="E-mail" className="w-full bg-brand-beige p-5 rounded-xl outline-none" onChange={ev => setE(ev.target.value)} />
        <button onClick={() => { onLogin(e, n); onClose(); }} className="w-full bg-brand-olive text-white py-5 rounded-xl font-bold uppercase tracking-widest text-[10px]">Entrar</button>
      </div>
    </div>
  );
};

const AddItemModal = ({ isOpen, onClose, onAdd }: any) => {
  const [p, setP] = useState({ name: '', price: 0, category: 'Cama', image: '', description: '' });
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm">
      <div className="bg-white w-full max-w-lg p-10 rounded-[32px] shadow-2xl space-y-4 animate-in zoom-in-95">
        <h2 className="text-3xl font-serif font-bold">Novo Item</h2>
        <div className="space-y-4">
          <input placeholder="Nome do Produto" className="w-full bg-brand-beige p-4 rounded-xl outline-none" onChange={ev => setP({...p, name: ev.target.value})} />
          <input placeholder="Preço (R$)" type="number" className="w-full bg-brand-beige p-4 rounded-xl outline-none" onChange={ev => setP({...p, price: parseFloat(ev.target.value)})} />
          <input placeholder="Link da Imagem (URL)" className="w-full bg-brand-beige p-4 rounded-xl outline-none" onChange={ev => setP({...p, image: ev.target.value})} />
          <select className="w-full bg-brand-beige p-4 rounded-xl outline-none" onChange={ev => setP({...p, category: ev.target.value})}>
             {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <textarea placeholder="Breve descrição" className="w-full bg-brand-beige p-4 rounded-xl outline-none min-h-[100px]" onChange={ev => setP({...p, description: ev.target.value})}></textarea>
        </div>
        <button onClick={() => onAdd(p)} className="w-full bg-brand-olive text-white py-5 rounded-xl font-bold uppercase tracking-widest text-[10px]">Publicar no Catálogo</button>
        <button onClick={onClose} className="w-full text-brand-gray text-[10px] uppercase font-bold">Cancelar</button>
      </div>
    </div>
  );
};

const CartDrawer = ({ isOpen, onClose, items }: any) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[1000]">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white p-8 flex flex-col shadow-2xl animate-in slide-in-from-right">
        <div className="flex justify-between items-center mb-8 border-b pb-4">
          <h3 className="text-3xl font-serif font-bold">Sacola</h3>
          <button onClick={onClose}><X size={32}/></button>
        </div>
        <div className="flex-grow overflow-y-auto space-y-6 scroll-hide">
          {items.map((i: any, idx: number) => (
            <div key={idx} className="flex gap-4 border-b border-brand-beige pb-4">
              <img src={i.image} className="w-20 h-20 object-cover rounded-xl" />
              <div className="flex flex-col justify-center">
                <p className="font-bold text-[10px] uppercase">{i.name}</p>
                <p className="text-brand-gold font-bold">R$ {i.price.toFixed(2)}</p>
              </div>
            </div>
          ))}
          {items.length === 0 && <p className="text-center py-20 text-brand-gray italic">Sua sacola está vazia.</p>}
        </div>
        <div className="border-t pt-6 space-y-4">
           <div className="flex items-center justify-center gap-2 text-brand-gold">
             <Lock size={12} />
             <span className="text-[9px] font-bold uppercase tracking-widest">SSL Seguro</span>
           </div>
           <button disabled={items.length === 0} className="w-full bg-brand-olive text-white py-5 rounded-xl font-bold uppercase tracking-widest text-[11px] shadow-lg disabled:opacity-50">Finalizar Compra</button>
        </div>
      </div>
    </div>
  );
}
